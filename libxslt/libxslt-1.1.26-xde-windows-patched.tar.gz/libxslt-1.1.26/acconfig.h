#undef HAVE_ISINF
#undef HAVE_ISNAN
#undef HAVE_POW
#undef HAVE_FLOOR
#undef HAVE_FABS
#undef WITH_DEBUGGER
